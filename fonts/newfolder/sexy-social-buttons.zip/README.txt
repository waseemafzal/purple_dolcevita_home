A Pen created at CodePen.io. You can find this one at http://codepen.io/minimalmonkey/pen/Ecpla.

 CSS only animation effect on hover of these simple but fun social buttons.